exports.ServerConfig = {
	user: 'cinepolis-web',
	password: '1234',
	server: 'localhost',
	database: 'Movies',
	options: {
		encrypt:false,
		"enableArithAbort":true
	}
};
exports.webPort=9000;